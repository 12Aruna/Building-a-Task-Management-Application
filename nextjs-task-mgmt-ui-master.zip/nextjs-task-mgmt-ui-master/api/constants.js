export const STATUS_OPTIONS = [
  { key: "OPEN", value: "OPEN", text: "OPEN" },
  { key: "IN_PROGRESS", value: "IN_PROGRESS", text: "IN_PROGRESS" },
  { key: "DONE", value: "DONE", text: "DONE" },
];
